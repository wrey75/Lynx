#include <stdio.h>
#include <X11/Xlib.h>
#include "XJS.h"

main(argc, argv)
    int argc;
    char **argv;
{
    Display *display;
    char *ret;
    int retlen;

    if (argc < 2) {
	fprintf(stderr, "need arg\n");
        exit(1);
    }
    display = XOpenDisplay(NULL);
    if (!XJSQueryExtension(display) || !XJSAYT(display)) {
	fprintf(stderr, "no XJS extension\n");
        exit(2);
    }
    if (XJSEval(display, argv[1], &ret, &retlen) > 0) {
        if (ret != NULL) {
	    fprintf(stderr, "%s\n", ret);
	}
    } else {
	fprintf(stderr, "XJSEval failed\n");
        exit(3);
    }
    exit(0);
}
