#include <stdio.h>
#include <X11/Xlib.h>
#include "XJS.h"

main(argc, argv)
    int argc;
    char **argv;
{
    Display *display;
    char *ret;
    int retlen;

    if (argc < 2) {
	fprintf(stderr, "need arg(s)\n");
        exit(1);
    }
    display = XOpenDisplay(NULL);
    if (!XJSQueryExtension(display) || !XJSAYT(display)) {
	fprintf(stderr, "no XJS extension\n");
        exit(2);
    }
    if (XJSCall(display, argv[1], &argv[2], argc - 2, &ret, &retlen) > 0) {
        if (ret != NULL) {
	    fprintf(stderr, "%s\n", ret);
	}
    } else {
	fprintf(stderr, "XJSCall failed\n");
        exit(3);
    }
    exit(0);
}
